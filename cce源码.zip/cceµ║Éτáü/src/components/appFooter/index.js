import appFooter from './appFooter.vue';

const AppFooter = {
  install(Vue) {
    Vue.component('appFooter', appFooter);
  },
};
export default AppFooter;
