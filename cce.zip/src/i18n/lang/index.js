import en from './en'
import zh from './zh'

export default {
  en,
  zh
}
