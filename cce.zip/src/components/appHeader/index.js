import appHeader from './appHeader.vue';

const AppHeader = {
  install(Vue) {
    Vue.component('appHeader', appHeader);
  },
};
export default AppHeader;
